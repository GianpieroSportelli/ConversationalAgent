package eu.reply;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * * Classe di configurazione, legge e fornisce le proprietà custom presenti in
 * apllication. properties * * @author Gianpiero Sportelli
 * (gi.sportelli@reply.it) *
 */
@Component
public class Configuration { 	
	//documentazione di spring per la configurazione esterna all'applicazione
	//https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html
	
	@Value("${path.semantic.net}")
	String url_semantic;
	
	@Value("${path.config}")
	String url_config;

	public String getUrl_semantic() {
		return url_semantic;
	}

	public String getUrl_config() {
		return url_config;
	}

}
