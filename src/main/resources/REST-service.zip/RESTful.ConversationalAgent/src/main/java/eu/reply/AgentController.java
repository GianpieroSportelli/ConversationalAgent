package eu.reply;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hp.hpl.jena.ontology.OntModel;

import configuration.Config;
import dialogManager.DialogManager;
import knowledge.KnowledgeBase;
import knowledge.KnowledgeBase_Reader;


@RestController
public class AgentController {

	private DialogManager bot;
	private KnowledgeBase kb;
	private JSONObject read;
	private float t = 0.9f;
	private Config conf_bot;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	public AgentController(Configuration conf){
		String url=conf.getUrl_semantic();
		logger.info("INIT: "+url);
		OntModel model = KnowledgeBase_Reader.readModel(url);
		kb = new KnowledgeBase(model);
		read = KnowledgeBase_Reader.readNLU(model);
		try {
			conf_bot=Config.getInstance(conf.getUrl_config());
		} catch (FileNotFoundException e) {
			logger.error("errore nel caricamento file di configurazione bot!!! verrà caricato quello di default");
			conf_bot=Config.getInstance();
		}
		bot=new DialogManager(kb,t,read,conf_bot);
	}

	@GetMapping("/test-rest")
	public String test_rest(@RequestParam(required = false, defaultValue = "World") String name) throws JSONException {
		JSONObject result = new JSONObject();
		try {
			result.accumulate("STATUS", "ok");
			result.accumulate("name", name);
		} catch (JSONException e) {
			result.accumulate("STATUS", "ERROR");
			e.printStackTrace();
		}
		return result.toString();
	}
	
	@CrossOrigin
	@RequestMapping(value="/bot", consumes="application/json",produces="application/json", method=RequestMethod.POST )
	@ResponseBody
	public String responseMessage(@RequestBody String body) throws JSONException, IOException {
		logger.info("Message: "+body);
		JSONObject request=new JSONObject(body);
		logger.info(" INPUT:\n"+request.toString(4));
		String m = request.getString("m");
		String id=request.getString("id");
		JSONObject result = new JSONObject();
		bot.setUser(id);
		bot.readMemory();
		result.accumulate("m", bot.streamMessage(m));
		bot.writeMemory();
		logger.info(" OUTPUT:\n"+result.toString(4));
		return result.toString();
	}
	
}
